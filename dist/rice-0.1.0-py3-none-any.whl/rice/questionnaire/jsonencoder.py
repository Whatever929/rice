import pandas as pd

class JSON_Encoder(object):
  # Encode using JSON, create a MultiEncoder with needed Encoder objects under the hood.
  pass