class Description(object):
  "Do we want to change this to dictionary object?"
  "Refer to https://stackoverflow.com/questions/3387691/how-to-perfectly-override-a-dict/39375731#39375731"
  def __init__(self, descrip):
    self.descrip = descrip